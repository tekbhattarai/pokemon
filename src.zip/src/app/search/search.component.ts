import { Component, OnInit } from '@angular/core';
import { PokemonService } from '../pokemon.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(public pokemon: PokemonService) { }
  public randomPokemon:any;
  public PokemonName:string="";
  ngOnInit(): void {

  }
  public pokemonInfo;
  public pokemonAbility: any[];
  public pokemonMove: any[];
  public pokemonSprites: any;
  public showAbility:boolean = false;
  public showMoves:boolean = false;
  public showSprites:boolean = false;
  getPokemon(){
    this.pokemon.getpokemon(this.PokemonName).subscribe(
      response=> {this.pokemonInfo = response
        this.pokemonAbility = this.pokemonInfo.abilities;
        this.pokemonMove = this.pokemonInfo.moves;
        this.pokemonSprites = this.pokemonInfo.sprites;
      // console.log(this.PokemonName)
       console.log(this.pokemonSprites.back_default);
    }
    );
    
    

  }
  changeAbility(){
    this.showAbility=true;
    this.showMoves=false;
    this.showSprites=false;
  }
  changeMoves(){
    this.showAbility=false;
    this.showMoves=true;
    this.showSprites=false;
  }
  changeSprites(){
    this.showAbility=false;
    this.showMoves=false;
    this.showSprites=true;
  }
}
